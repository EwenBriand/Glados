module Main (main) where

import REPL

main :: IO ()
main = runREPL

