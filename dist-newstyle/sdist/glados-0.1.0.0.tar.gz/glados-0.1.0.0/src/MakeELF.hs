module MakeELF (

) where

import Data.Elf

