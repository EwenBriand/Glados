
-- myVariable :: Definition
-- myVariable = GlobalDefinition globalVariableDefaults
--     { name = Name "myVariable"
--     , linkage = Private
--     , visibility = Default
--     , threadLocalMode = Nothing
--     , addrSpace = 0
--     , type' = IntegerType 32
--     , initializer = Just (Int 32 0)
--     , section = Nothing
--     , alignment = 4
--     }

